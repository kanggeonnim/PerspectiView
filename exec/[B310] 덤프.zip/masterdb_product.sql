-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `category_id` bigint DEFAULT '1',
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `product_imageurl` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtpncn169tudu03juyb5lerua4` (`team_id`),
  KEY `FK1mtsbur82frn64de7balymq9s` (`category_id`),
  CONSTRAINT `FK1mtsbur82frn64de7balymq9s` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FKtpncn169tudu03juyb5lerua4` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (2,2,3,'faaa','http://sijack.s3-website.kr.object.ncloudstorage.com/images/99e54ae9-fa11-46f4-87ca-542675842efe1213.jpeg','faaaa'),(1,4,8,'작품1 내용','http://sijack.s3-website.kr.object.ncloudstorage.com/images/3d4e32d2-b4c3-48ee-913d-5c59fef5e4888930263615_1.jpg','작품1'),(1,6,3,'faㅁㅁ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/a4262d70-6966-4794-96c0-9746157b01871213.jpeg','faㅁㅁ'),(1,9,5,'10기 싸피생 김싸피는 오늘도 침대에서 일어나 셔틀을 탄다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/debe672a-d470-42e4-bedd-d7173e2addb8ssafy.png','김싸피의 일상'),(1,10,2,'f',NULL,'f'),(1,26,6,'sdfs',NULL,'sdfsd'),(1,27,6,'zxczx',NULL,'xzczc'),(1,28,6,'zxczx',NULL,'zxczx'),(1,29,6,'테스트2',NULL,'테스트1'),(1,69,3,'작가','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8f2f2ec3-98b3-49bb-b5ea-61d33ee5e87cwriter.png','작가람쥐'),(3,76,3,'GOD','http://sijack.s3-website.kr.object.ncloudstorage.com/images/1f78e908-2a4a-4bde-b70d-35bd609f3f274EW7VzUkEobajV5QsUMoBV-nwMxC6ZTqrvqnzm3_O1OnWYBkVJ44gScHW3EqVOeWPbWydMed-_OMiclTLEuRiw.webp','GOD김치'),(1,80,2,'f','http://sijack.s3-website.kr.object.ncloudstorage.com/images/1c29301f-11af-452c-9129-d84b0be15428cer.png','f'),(1,83,4,'ㅋ',NULL,'작품생성 테스트'),(1,84,5,'김싸피는 언니와 함께 강둑에 앉아 아무 것도 하지 않고 있자니 점차 몹시 지루해졌다. ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/679ce3db-3c54-45ff-a433-2ba2c484951f앨리스 표지.png','이상한 나라의 김싸피'),(1,85,1,'김싸피는 어린 소녀로 토끼를 따라가다가 굴에 빠졌다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/00619cf5-b2e0-4d61-abad-ed95fc798a58앨리스 표지.png','이상한 나라의 김싸피'),(1,86,2,'역도의 마스터','http://sijack.s3-website.kr.object.ncloudstorage.com/images/453f775b-9a36-4455-a920-7a0a3d632d1ccer.png','certbot의 역기쇼'),(1,88,8,'김싸피는 어린 소녀로 토끼를 따라가다가 굴에 빠졌다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/bb758a80-ff35-41c7-9dc7-2c88fe887b94앨리스 표지.png','이상한 나라의 김싸피'),(1,89,6,'retrt',NULL,'ertt'),(1,90,6,'werwer',NULL,'werwer'),(1,91,6,'ㄴㅇㄹㄴㅇㄹ',NULL,'ㅇㄴㄹㄴㅇㄹ'),(1,122,61,'123',NULL,'123'),(1,123,62,'',NULL,'기타 멘 로미오'),(1,124,64,'바다소년 소녀의 만남','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e08a864d-af74-4122-a4a2-3b0e3c882907iridescent-pastel-background.jpg','동해 속 진주'),(1,125,28,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/50cac857-74c0-4768-b29c-002ad1f358c6앨리스.jpg','공동작업 테스트'),(1,132,5,'하기',NULL,'게임스토리'),(4,139,5,'10기 싸피생 김싸피는 오늘도 침대에서 일어나 셔틀을 탄다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/03294e7b-0501-4df0-ab53-dc6c403b19a8ssafy.png','김싸피의 일상'),(1,140,27,'SDFSD',NULL,'SDFSDF'),(1,141,65,'번역 프로젝트',NULL,'RESTful API CookBook'),(1,161,3,'string','http://sijack.s3-website.kr.object.ncloudstorage.com/images/ec5e9e09-a6f4-4962-b2c6-9e22cb4f9504why we use tanstack query.jpg','string'),(1,175,27,'작품생성11',NULL,'작품생성 테스트'),(5,178,6,'작품생성테스트1','http://sijack.s3-website.kr.object.ncloudstorage.com/images/3763c757-d6e7-40a7-adad-75b3ebbe15a1image (1).png','작품생성테스트'),(5,179,68,'생성',NULL,'생성테스트11'),(2,180,68,'생성테스트 ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/21cdf0d1-6254-448a-ab93-615f2802aa98image (1).png','생성테스트2_이미지'),(2,183,4,'string',NULL,'string'),(2,184,1,'','http://sijack.s3-website.kr.object.ncloudstorage.com/images/923c8f42-8a14-4083-ac57-01e30681aed5지구의 마지막날.png','지구의 마지막날'),(2,185,70,'걸리버가 소인국에 왔다','http://sijack.s3-website.kr.object.ncloudstorage.com/images/a4eb23dd-d7b6-4449-aefa-d882cc5dd47d걸리버_여행기.jpeg','걸리버 여행기'),(1,186,1,'','http://sijack.s3-website.kr.object.ncloudstorage.com/images/93ee6536-c760-4915-ab17-0f03008cbb0e달러구트 꿈 백화점.jpg','작품 생성 '),(4,187,1,'이상한 나라에 떨어진 김싸피','http://sijack.s3-website.kr.object.ncloudstorage.com/images/9476f6bf-f12d-4b3f-b6f5-19ffb5896980앨리스 표지.png','이상한 나라의 김싸피'),(2,188,70,'앨리스는 어린 소녀로 토끼를 따라가다가 굴에 빠졌다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/099cfa0c-3653-43ae-b82f-722d575d7ffd앨리스 표지.png','이상한 나라의 김싸피'),(2,189,70,'엘리자베스와 다아시가 서로를 오해하다가 사랑에 빠지는 이야기','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e33d745d-59d7-4b03-89ad-1c055975b2fc오만과 편견.jfif','오만과 편견'),(2,190,70,'톰 소여의 모험','http://sijack.s3-website.kr.object.ncloudstorage.com/images/ce548777-b54b-4487-bda4-a0c4f56b2042톰소여의모험.jpg','톰소여의 모험'),(5,191,70,'인력거꾼의 이야기','http://sijack.s3-website.kr.object.ncloudstorage.com/images/4569842e-994e-4bca-b682-6e6599c9ff4c운수좋은날.jpg','운수 좋은 날'),(2,192,70,'산 정상에서 추락한 남자의 변사사건, 그의 아내와 형사가 만난다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f7af4204-bf3e-4906-862e-e12c30d76dd1헤어질결심.jpg','헤어질 결심'),(2,193,70,'아동 심리학자 말콤이 귀신을 보는 아이 콜을 만난다','http://sijack.s3-website.kr.object.ncloudstorage.com/images/203b56b8-4e29-4533-abf0-95a221bff2d5식스센스_포스터.jpg','식스센스'),(2,194,70,'취업 준비생인 페니가 달러구트 꿈 백화점에 취직하며 겪는 일','http://sijack.s3-website.kr.object.ncloudstorage.com/images/cdd2d661-939d-454f-9563-431f7b02166e달러구트 꿈 백화점.jpg','달러구트 꿈 백화점 '),(5,197,1,'6센스','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f6635279-e109-4010-9bb0-baed440204b7식스센스_포스터.jpg','식스센스2'),(2,198,85,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/9ad8b3a5-bfbe-4050-80c7-636faf533c13식스센스_포스터.jpg','식스센스3'),(5,199,86,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f23f3932-b89e-424f-9e6a-38a2f4c9c41d식스센스_포스터.jpg','식스센스444'),(1,201,53,'test',NULL,'test'),(1,202,53,'test',NULL,'test'),(1,205,14,'',NULL,'12'),(2,206,87,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8be98680-ad16-4a20-9081-6d9193191afd식스센스_포스터.jpg','식스센스2'),(5,207,88,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8a70eb17-8f82-4b99-a7fb-b33f391a3dbf콜 엄마-modified.png','식스센스33'),(5,208,89,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/9b57e1b4-bf47-4efa-a94b-41f1a22ded00말콤-modified.png','식스센스'),(2,211,1,'','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f35cf88c-3358-40e2-a60b-3202cd581ea7걸리버_여행기.jpeg','걸리버 여행기'),(1,214,8,'',NULL,''),(2,215,3,'12333','http://sijack.s3-website.kr.object.ncloudstorage.com/images/3c259662-792f-41b5-843a-f5c8a31258a3123.jpeg','댄싱퀸이봉주'),(1,216,8,'test',NULL,'test'),(1,217,8,'test',NULL,'test'),(1,218,8,'test',NULL,'test'),(1,219,14,'qi',NULL,'wj'),(2,220,90,'테스트에요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/1292afce-eed6-4c09-8160-e4d8ea9a12f4달러구트 꿈 백화점.jpg','달러구트');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:12
