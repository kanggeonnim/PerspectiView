-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `create_at` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `provider` varchar(255) NOT NULL,
  `provider_id` varchar(255) NOT NULL,
  `user_image_url` varchar(255) DEFAULT NULL,
  `user_info` varchar(255) DEFAULT NULL,
  `user_nickname` varchar(255) NOT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('2024-02-10 21:53:07.282137',1,'ssayeonfy@gmail.com','google','107247675043333985409',NULL,NULL,'심지연 작가님',NULL,'google_107247675043333985409'),('2024-02-12 20:26:11.116241',2,'yjk98053@gmail.com','google','101696362655522382485',NULL,NULL,'유재건작가님',NULL,'google_101696362655522382485'),('2024-02-12 20:26:32.294033',3,'questional777@gmail.com','google','112165877687194035057',NULL,NULL,'우재하작가님',NULL,'google_112165877687194035057'),('2024-02-12 20:27:14.773829',4,'gun0680@nate.com','kakao','3298044440',NULL,NULL,'강건작가님',NULL,'kakao_3298044440'),(NULL,5,'test@naver.com','naver','9912324568798654',NULL,NULL,'test_nickname',NULL,'test_username'),('2024-02-12 20:29:47.665282',6,'gkdrhd6788@naver.com','kakao','3331216706',NULL,NULL,'권수지작가님',NULL,'kakao_3331216706'),('2024-02-12 20:34:19.721915',7,'sjytis14@gmail.com','google','100945562307024095454',NULL,NULL,'대전_8반_임서정작가님',NULL,'google_100945562307024095454'),('2024-02-13 08:51:34.875245',8,'jaeha6049@kakao.com','kakao','3333125010',NULL,NULL,'우재하작가님',NULL,'kakao_3333125010'),('2024-02-13 11:39:48.018046',9,'nv_tkwjsrjatn2@naver.com','naver','m0hQsBOokULxoNFcmNL0pfih2vrSDmejDWwYIXariN4',NULL,NULL,'네아로작가님',NULL,'naver_m0hQsBOokULxoNFcmNL0pfih2vrSDmejDWwYIXariN4'),('2024-02-15 02:37:18.865433',10,'gun4329@gmail.com','google','116021925318823901352',NULL,NULL,'대전_3반_강건작가님',NULL,'google_116021925318823901352'),('2024-02-15 02:37:33.188874',11,'gun7759@naver.com','naver','iYTqHokoaTey957nTP0Y7FTTJkFw3rb9UdMxNA1-Fn8',NULL,NULL,'강건작가님',NULL,'naver_iYTqHokoaTey957nTP0Y7FTTJkFw3rb9UdMxNA1-Fn8'),('2024-02-15 03:55:10.135219',12,'ghks8998@naver.com','kakao','3338951088',NULL,NULL,'샤니작가님',NULL,'kakao_3338951088'),('2024-02-15 04:05:16.647147',13,'skdkskthk@naver.com','kakao','3343356729',NULL,NULL,'이시억작가님',NULL,'kakao_3343356729'),('2024-02-15 07:49:15.844433',14,'rlatlghks8998@gmail.com','google','105348624181588016624',NULL,NULL,'샤니작가님',NULL,'google_105348624181588016624'),('2024-02-15 10:34:01.563542',15,'cheuora@gmail.com','google','117282990792345287651',NULL,NULL,'Kim Sungjoon작가님',NULL,'google_117282990792345287651'),('2024-02-15 10:45:12.118840',16,'danny100e@gmail.com','kakao','3343615085',NULL,NULL,'현준작가님',NULL,'kakao_3343615085');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:08
