-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `positionx` double DEFAULT NULL,
  `positiony` double DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `character_detail` varchar(255) DEFAULT NULL,
  `character_image_url` varchar(255) DEFAULT NULL,
  `character_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtc2j2b6iorp9lk2x5v4vnx39r` (`product_id`),
  CONSTRAINT `FKtc2j2b6iorp9lk2x5v4vnx39r` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (150,250,1,69,'뭘봐','http://sijack.s3-website.kr.object.ncloudstorage.com/images/cf601503-6253-4007-a621-a19dc3d5f5dehand-writing-with-ballpen.png','펜잡이'),(100,100,2,69,'punch','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e80f11c0-d749-4584-b8c2-cc5a6de26555high-five.png','주먹다짐 '),(0,0,3,69,'string','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8c9b8f97-8702-473b-b93c-7178bbac6d7dwriter.png','작가'),(0,0,4,69,'추가함','http://sijack.s3-website.kr.object.ncloudstorage.com/images/aa829e56-66ec-4cc8-8c00-ffefba34662bwriter.png','작가'),(0,0,5,69,'추가됨','http://sijack.s3-website.kr.object.ncloudstorage.com/images/7d9f116f-ba61-4430-84c7-9b0b61cfd513다운로드.png','추가함'),(0,0,6,4,'주인공',NULL,'공유'),(0,0,7,9,'김싸피는 싸피 10기생이며 2학기 공통 프로젝트를 시작했다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/21750f69-cbe9-45e9-bac5-15a0c2be6000ssafy.png','김싸피'),(0,0,9,69,'쑥쑥','http://sijack.s3-website.kr.object.ncloudstorage.com/images/2df1068e-a04a-45f8-a8eb-918080e1f3c4line-graph.png','떡상이'),(0,0,10,69,'복잡','http://sijack.s3-website.kr.object.ncloudstorage.com/images/74006043-51d6-4e84-87a5-b5d570ad97ffbusiness-analyst.png','복잡이'),(0,0,13,69,'날카로운 연필','http://sijack.s3-website.kr.object.ncloudstorage.com/images/06167a3d-c48f-447d-8c2d-aaa6458b1384copywriter.png','연필이'),(0,0,14,6,'추가요','http://sijack.s3-website.kr.object.ncloudstorage.com/images/89558111-d7e3-4a18-85e1-b25cc5f2eef7icon_4.png','추가합니다'),(0,0,15,4,'주인공',NULL,'정유미'),(0,0,16,9,'앨리스는 어린 소녀로 토끼를 따라가다가 굴에 빠졌다.',NULL,'앨리스'),(0,0,17,9,'앨리스가 따라간 바로 그 토끼','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d524e4a1-9a5e-4288-a749-2a83df841667흰토끼.jpg','흰토끼'),(0,0,18,9,'잔혹한 하트 여왕','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8330ad3c-1f02-4a94-82f6-6ff782a2bd98하트여왕.png','여왕'),(0,0,19,9,'사라지는 고양이','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8e37b02d-ab0d-4f81-a7ba-b37f1675cb7a체셔고양이.png','체셔 고양이'),(0,0,20,9,'뾰족','http://sijack.s3-website.kr.object.ncloudstorage.com/images/7e3fb26e-8d5f-437c-b7fd-87eac219351ccopywriter.png','연필'),(0,0,21,69,'!','http://sijack.s3-website.kr.object.ncloudstorage.com/images/c2678748-0baf-4668-b953-725f039f8960careful.png','!'),(0,0,22,9,'앨리스는 어린 소녀로 토끼를 따라가다가 굴에 빠졌다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/405c8b40-6c36-4250-99e6-6612844a6972앨리스.jpg','앨리스'),(0,0,23,76,'열혈 작가','http://sijack.s3-website.kr.object.ncloudstorage.com/images/5c2de1ce-8281-4fb8-b98c-dc2ddbdd9107writer.png','작가'),(0,0,24,76,'범생','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d99ddf37-8794-4573-afbd-0ce08bdc1584copywriter.png','범생이'),(0,0,25,76,'ㅇㅇ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/84d1458a-6a3f-46aa-ae5a-3bd58cea802ecareful.png','훈남'),(0,0,26,76,'아우우','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f59f1fab-dcf4-4db3-9dbb-7c9322f1b802다운로드.jpg','늑대인간'),(0,0,29,88,'앨리스가 따라간 흰 토끼','http://sijack.s3-website.kr.object.ncloudstorage.com/images/82bc03eb-59d3-4583-9b43-7998aa87be3b흰토끼.png','흰토끼'),(0,0,30,88,'당연하지만 고양이를 싫어한다','http://sijack.s3-website.kr.object.ncloudstorage.com/images/32c95c1c-7f53-4f3b-9af9-41994c9c8299생쥐.png','생쥐'),(0,0,31,88,'물담배를 피고 있는 애벌레','http://sijack.s3-website.kr.object.ncloudstorage.com/images/5d32996e-e686-4340-9234-1b0b2adb0b7f애벌레.png','애벌레'),(0,0,32,88,'웃고 있는 고양이','http://sijack.s3-website.kr.object.ncloudstorage.com/images/39ac90d6-a46d-4c12-8621-456016663957체셔고양이.png','체셔 고양이'),(0,0,33,88,'앨리스가 아니라 김싸피','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8e2ef738-8cc5-4091-88a9-16ef5ffe91b2김싸피.png','김싸피'),(0,0,34,88,'툭하면 사형하라고 하는 여왕','http://sijack.s3-website.kr.object.ncloudstorage.com/images/eaa9ba45-a7bf-42b6-85c8-fbf3e006cb2d하트여왕.png','하트여왕'),(0,0,36,124,NULL,'http://sijack.s3-website.kr.object.ncloudstorage.com/images/55273eb2-af5f-4c4e-b321-7cf030991011tumblr_prs46amqUO1ug1t6jo1_540.png','동해'),(0,0,37,83,'특징 평범하다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/f84c712e-df41-4d7e-bfa3-02f9f4a007f4다운로드 (3).png','등장인물1'),(0,0,38,83,'기억을 잘한다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e546e1bf-ef6c-468e-8707-339aa46c4a3b다운로드 (3).png','레디스'),(0,0,39,69,'22','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d4e1cff4-89ec-4a05-abdf-cb57eb62fbf6communication.png','test'),(0,0,40,26,'asdfasdfasdf',NULL,'asdfasd'),(0,0,41,26,'sdfsd',NULL,'sdfsd'),(0,0,42,86,'ff','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e97b7681-ddd1-4bc2-80ca-3b36628b48f8cer.png','certbot'),(0,0,43,86,'fff','http://sijack.s3-website.kr.object.ncloudstorage.com/images/590bd8da-7d70-4e56-bed9-26f033b076f0je.jpg','jenkins'),(0,0,44,2,'test','http://sijack.s3-website.kr.object.ncloudstorage.com/images/4752b818-e40e-45ab-966d-fc3cfbbba62dhand-writing-with-ballpen.png','test'),(0,0,45,2,'22','http://sijack.s3-website.kr.object.ncloudstorage.com/images/3bea24b5-1725-4f7f-8dc4-f7450c916242copywriter.png','test2'),(0,0,47,179,'권수지','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e47f5b79-1d63-420e-a39d-0103dc34cfb2image (1).png','권수지'),(0,0,48,179,'ㅇㅇ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/20db0087-3fd3-40ea-b88f-c57fcf556562image (1).png','임서정'),(0,0,49,179,'ㅇㅇ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/e0f22cfa-fcbe-4a9b-a2ec-ba1f5cd259e2image (1).png','우재하'),(0,0,50,161,'123','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8818e4a2-4352-4cf3-8f56-d0b5b9a54999why we use tanstack query.jpg','123'),(0,0,51,161,'123','http://sijack.s3-website.kr.object.ncloudstorage.com/images/676e15af-0f22-4603-994c-47d416cd369cwhy we use tanstack query.jpg','123'),(0,0,52,85,'헤엄치는 생쥐','http://sijack.s3-website.kr.object.ncloudstorage.com/images/421bf8e0-4bb3-48ad-99d4-b3c9fd74108e생쥐.png','생쥐'),(0,0,53,86,'ffff',NULL,'ff'),(0,0,54,84,'fff','http://sijack.s3-website.kr.object.ncloudstorage.com/images/39ca7adf-beeb-4594-ad6b-586711c9124dgitlab.png','ffff'),(0,0,55,84,'www','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d1ef0783-22b9-4664-99d5-5a8a83fe9b76re.png','fffwww'),(0,0,56,2,'123','http://sijack.s3-website.kr.object.ncloudstorage.com/images/b65276a3-a8b5-464a-91c0-b217020db9facareful.png','123'),(0,0,57,132,'테스트용 캐릭터',NULL,'테스트 캐릭터'),(0,0,58,84,'강건이다',NULL,'강건'),(0,0,59,4,'test','http://sijack.s3-website.kr.object.ncloudstorage.com/images/5665e929-253f-4ec7-b74d-219944681672Group 2.png','test'),(0,0,60,193,'아동 심리학자로 1년전 죽고 현재 유령 상태','http://sijack.s3-website.kr.object.ncloudstorage.com/images/50eb6038-3dbc-46a7-a6bf-17acf78e2967말콤-modified.png','말콤'),(0,0,61,193,'말콤의 아내, 남편을 추모한다','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d8d57355-7620-4c3b-8b7e-5188b688fdd6말콤아내-modified.png','애나'),(0,0,62,193,'유령을 보는 아이. 그래서 별종 취급을 받으며 따돌림 당한다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/021548c1-7436-4db0-baf9-f7a84855594f콜-modified.png','콜'),(0,0,63,193,'콜의 엄마. 콜이 나중에 할머니가 해준 말을 듣고 운다.','http://sijack.s3-website.kr.object.ncloudstorage.com/images/d39625c0-06d2-40f9-9cd8-05257955a718콜 엄마-modified.png','콜 엄마'),(0,0,64,205,'23123','http://sijack.s3-website.kr.object.ncloudstorage.com/images/eeb81cd9-9ae0-4b1d-880e-744f5e1d0d8c1213.jpeg','123'),(0,0,65,205,NULL,'http://sijack.s3-website.kr.object.ncloudstorage.com/images/88e6f0bf-a67e-4e48-a047-4468716811ee1213.jpeg','123'),(0,0,67,205,'123','http://sijack.s3-website.kr.object.ncloudstorage.com/images/5109cb03-a528-4481-bf69-34d21a12355b1213.jpeg','123'),(0,0,69,193,'ㅇㄹㄴ','http://sijack.s3-website.kr.object.ncloudstorage.com/images/8f3576c8-2bf2-4161-ba75-b95169d5fe1c생쥐.png','샹주');
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:08
