-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plot`
--

DROP TABLE IF EXISTS `plot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `color` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnmrm2iq0salouyl4a770jj4le` (`product_id`),
  CONSTRAINT `FKnmrm2iq0salouyl4a770jj4le` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plot`
--

LOCK TABLES `plot` WRITE;
/*!40000 ALTER TABLE `plot` DISABLE KEYS */;
INSERT INTO `plot` VALUES (1,4,'#cd93ff','플롯1'),(2,4,'#ffa647','플롯2'),(3,4,'#ffe83f','플롯3'),(4,4,'#ff75c3','tttessssttt'),(5,4,'#9fff5b','플롯4'),(11,9,'#26A69A','챕터1'),(12,9,'#5C6BC0','챕터2'),(21,9,'#FB8C00','챕터3'),(22,26,'#ff75c3','sdfsd'),(23,26,'#ff75c3','sdfsd'),(24,26,'#ff75c3','sdfsd'),(25,26,'#ff75c3','sdfsd'),(26,26,'#ff75c3','sdfsdsdfs'),(27,26,'#E2E2E2','sdfsdsdfs'),(28,26,'#E2E2E2','sdfsdsdfs'),(29,26,'#E2E2E2','sdfsdsdfs'),(30,26,'#ff75c3','ZxZ'),(31,26,'#ff75c3','ZxZ'),(32,26,'#ff75c3','ZxZ'),(33,26,'#ffa647','sdfsdf'),(34,26,'#09203f','testtest'),(35,69,'#cd93ff','123'),(36,69,'#ff75c3','123'),(37,69,'#ff75c3','123 '),(38,69,'#ff75c3','123 '),(39,69,'#ff75c3','123 '),(40,69,'#ff75c3','123 '),(41,9,'#70e2ff','챕터4'),(42,26,'#D1180B','ㄴㅇㄹㄴㅇ'),(43,9,'#ff75c3','챕터5'),(620,83,'#cd93ff','플롯생성 테스트'),(621,83,'#cd93ff','플롯생성 테스트'),(622,83,'#ffa647','플롯생성 테스트'),(623,84,'#cd93ff','토끼굴 속으로'),(625,88,'#70e2ff','토끼굴 속으로'),(626,88,'#ff75c3','눈물 웅덩이'),(627,88,'#cd93ff','코커스 경주와 긴 이야기'),(628,88,'#ffe83f','애벌레의 충고'),(629,88,'#ff75c3','미치광이 다과회'),(630,88,'#D1180B','여왕의 크로켓 경기장'),(634,83,'#ffa647',''),(635,122,'#ff75c3',''),(636,122,'#ffe83f',''),(637,122,'#ffe83f',''),(638,85,'#ff75c3','챕터1'),(639,83,'#ff75c3',''),(640,124,'#ff75c3','첫만남'),(641,124,'#ff75c3','첫만남'),(642,83,'#ff75c3',''),(643,85,'#ff75c3','테스트'),(1196,2,'#ff75c3','풋풋'),(1197,2,'#ff75c3','풋풋2'),(1198,141,'#ff75c3','복자의  하루 일과'),(1199,141,'#ff75c3','복자의  하루 일과'),(1200,141,'#ff75c3','복자의  하루 일과'),(1201,132,'#ff75c3','테스트'),(1301,86,'#ff75c3','시작'),(1302,6,'#ff75c3','분홍이'),(1303,88,'#9fff5b','김싸피의 증언'),(1305,179,'#ff75c3','기'),(1306,179,'#ffe83f','승'),(1307,132,'#ff75c3','테스트'),(1607,84,'#ff75c3',''),(1608,183,'#ff75c3',''),(1609,183,'#ff75c3',''),(1610,183,'#ff75c3',''),(1611,183,'#ff75c3',''),(1612,183,'#ff75c3',''),(1613,183,'#ff75c3',''),(1614,183,'#ff75c3',''),(1615,183,'#ff75c3',''),(1616,185,'#ffa647','릴리퍼트'),(1617,2,'#ff75c3','프프'),(1621,193,'#9fff5b','심리학자, 말콤'),(1622,193,'#ff75c3','따돌림 받는, 콜'),(1623,193,'#70e2ff','귀신을 보는 아이'),(1624,193,'#E2E2E2','서먹한 아내'),(1625,193,'#D1180B','유령을 돕는 콜'),(1626,193,'#09203f','고백'),(1627,193,'#ffa647','결말');
/*!40000 ALTER TABLE `plot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:06
