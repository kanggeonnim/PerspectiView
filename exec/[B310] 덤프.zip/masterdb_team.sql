-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `personal` bit(1) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `info` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (_binary '',1,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',2,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',3,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',4,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',5,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',6,'수정테스트1 내용','Personal Team'),(_binary '',8,'수정테스트1 내용','Personal Team'),(_binary '',14,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',15,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '\0',24,'추가합니다','팀1'),(_binary '\0',26,'',''),(_binary '\0',27,'팀~~~~','팀1'),(_binary '\0',28,'10기의 작가방입니다','싸피10기 작가방'),(_binary '\0',48,'why?','팀팀'),(_binary '\0',52,'팀 생성','팀생성1'),(_binary '\0',53,'팀 생성2','팀 생성2'),(_binary '\0',54,'팀3','팀3'),(_binary '\0',55,'ㄴㅇㄹㅇㄴㄹ','alert팀생성'),(_binary '\0',56,'sdfsf','팀생성 새로고침 x'),(_binary '\0',59,'sdfsd','sdfsdf'),(_binary '',60,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',61,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',62,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',63,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',64,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',65,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '',66,'개인 작품이 저장되는 공간 입니다.','Personal Team'),(_binary '\0',67,'팀 생성','팀생성티'),(_binary '\0',68,'팀 생성 테스트 ','팀 생성 테스트'),(_binary '\0',69,'싸피 작가들을 위한 방','10기 작가방'),(_binary '\0',70,'취미 작가에 대한 꿈이 있는 싸피생들을 위한 팀입니다.','싸피 10기 작품 스터디'),(_binary '\0',71,'우리팀이어떤팀이냐면요우리팀이어떤팀이냐면요우리팀이어떤팀이냐면요우리팀이어떤팀이냐면요우리팀이어떤팀이냐면요','팀 수정'),(_binary '\0',72,'','팀 생성'),(_binary '\0',73,'text-nowraptext-nowraptext-nowraptext-nowrap','팀 이름'),(_binary '\0',74,'ㅁㄴㅇㄴㅁㅇ','ㅁㄴㅇㅁㄴㅇ'),(_binary '\0',77,'','진짜되나'),(_binary '\0',79,'','진짜'),(_binary '\0',81,'ttt','fttt'),(_binary '\0',82,'dd','testestest'),(_binary '\0',83,'',''),(_binary '\0',84,'',''),(_binary '\0',85,'10기 작가방 ','10기 작가방'),(_binary '\0',86,'10기 작가방','10기 작가방'),(_binary '\0',87,'10기 작가방','10기 작가방'),(_binary '\0',88,'10기 작가방','10기 작가방'),(_binary '\0',89,'10기 작가방','10기 작가방'),(_binary '\0',90,'10기 작가방','10기 작가방');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:13
