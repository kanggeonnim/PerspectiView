-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `story`
--

DROP TABLE IF EXISTS `story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story` (
  `positionx` int NOT NULL,
  `positiony` double NOT NULL,
  `content_id` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plot_id` bigint DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_me1ro1u9uhxywcm66up9xy3bf` (`content_id`),
  KEY `FKg930nhvfaccliyjfu72kku4ve` (`plot_id`),
  CONSTRAINT `FKg930nhvfaccliyjfu72kku4ve` FOREIGN KEY (`plot_id`) REFERENCES `plot` (`id`),
  CONSTRAINT `FKjp6dppcrymsmh40nr5d0gn7sm` FOREIGN KEY (`content_id`) REFERENCES `content` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story`
--

LOCK TABLES `story` WRITE;
/*!40000 ALTER TABLE `story` DISABLE KEYS */;
INSERT INTO `story` VALUES (7,-100,3,3,12,'흰토끼를 만나다'),(7,180,4,4,11,'앨리스 토끼굴로 빠지다'),(6,240,5,5,11,'오렌지 마멀레이드'),(5,320,6,6,11,'\"날 마셔요\"'),(4,240,7,7,11,'케이크'),(5,-320,11,11,12,'코커스 경주와 긴 이야기'),(4,-260,12,12,12,'김싸피 배고프다'),(3,-760,13,13,12,'김싸피 아침 간식을 먹는다'),(2,-140,14,14,12,'김싸피 점심시간이 되다'),(1,-220,15,15,12,'김싸피 점심을 먹다'),(0,-20,16,16,12,'김싸피 산책을 나가다'),(7,-300,17,17,21,'김싸피 오후일과를 시작하다'),(6,200,18,18,21,'김싸피 졸다'),(5,60,20,20,21,'김싸피 꿈꾸다'),(4,-420,21,21,21,'김싸피 나비?'),(1,0,22,22,34,''),(1,0,23,23,22,'스토리23'),(2,-200,27,27,21,'나비는 날아다닌다'),(0,80,29,29,21,'나비는 날아다닌다'),(1,-100,30,30,41,''),(1,0,31,31,42,''),(1,-120,32,32,23,'스토리 32'),(1,220,33,33,24,'스토리33'),(0,0,41,41,11,'업데이트 언제 날아갈까'),(21,60,45,45,43,'스토리 제목을 입력하세요.'),(1,0,67,67,35,''),(1,0,74,74,620,'string?????????????뭐냐이건어라 바로되네이제..ㅇㅇ.'),(1,0,75,75,621,'흠?ㅋ'),(1,-160,76,76,622,'스토리 제목을 입력하세요.123'),(1,0,77,77,623,'바꾸기'),(4,80,79,79,625,'언니와 강둑에 놀러가다'),(1,-240,80,80,626,'눈물을 흘리는 김싸피'),(1,-100,82,82,627,'도도새를 만나다'),(1,-200,83,83,628,'물담배를 피는 애벌레'),(1,-360,84,84,629,'Mad Hatter'),(1,-480,85,85,630,'목을 매우 쳐라'),(3,-60,87,87,625,'토끼 발견'),(1,0,88,88,637,'스토리 제목을 입력하세요.'),(1,0,89,89,636,'스토리 제목을 입력하세요.'),(1,0,90,90,635,'string?????????????뭐냐이건'),(1,0,91,91,634,'아아ㅏ`'),(1,0,92,92,638,'지금은 새벽 3시 43분'),(1,0,98,98,639,'스토리 제목을 입력하세요.'),(1,40,102,102,1,'스토리 제목을 입력하세요.'),(1,20,109,109,2,'ㅇㄴㄹㅇㄹㄴㅇㄹㄴㅇㄹㄴ'),(1,40,110,110,640,'스토리 제목을 입력하세요.'),(1,0,111,111,643,'스토리 제목을 입력하세요.'),(1,0,112,112,1198,'스토리 제목을 입력하세요.'),(2,0,113,113,1301,'fffffffff요.'),(1,-20,114,114,3,'스토리 제목을 입력하ㄴㅇㄹㅇㄴㄹ세요.'),(1,0,115,115,4,'111'),(1,-100,117,117,5,'123123123sdfsdfsdfdssdfsdfdsfsfsfsdfdfsfdㄴㅇㄹㅇㄴㄹㅇㄴㄹㄴㅇsfsd'),(2,-180,119,119,625,'몸이 작아지다'),(1,0,122,122,1196,'스토리 제목을 입력하세요.'),(1,0,123,123,1302,'스토리 제목을 입력하세요.'),(1,-200,126,126,1303,'김싸피의 증언'),(1,-80,128,128,1305,'기_스토리1'),(1,0,129,129,1306,'승_스토리1'),(1,0,130,130,642,'스토리 제목을 입력하세요.ㅋㅋ'),(321,0,131,131,1201,'string'),(213,0,242,242,1201,'testStory'),(1,0,243,243,1607,'제목'),(1,0,254,254,1608,'스토리 제목을 입력하세요.dd'),(4,0,355,355,1609,'스토리 제목을 입력하세요.'),(2,0,356,356,1609,'string'),(1,0,357,357,1609,'string'),(0,0,358,358,1609,'string'),(14,0,360,359,1615,'string111111'),(13,0,361,360,1615,'string1122221111'),(12,0,362,361,1615,'string1122221111'),(11,0,363,362,1615,'string1122221111'),(10,0,364,363,1615,'string1122221111'),(9,0,365,364,1615,'string1122221111'),(8,0,367,366,1615,'string1122221111'),(7,0,368,367,1615,'string1122221111'),(6,0,369,368,1615,'string1122221111'),(5,0,370,369,1615,'string1122221111'),(4,0,371,370,1615,'string1122221111'),(3,0,374,373,1615,'string1122221111'),(2,0,375,374,1615,'string1122221111'),(1,0,376,375,1615,'string1122221111'),(0,0,378,377,1615,'string1122221111'),(1,0,480,479,1616,'스토리 제목을 입력하세요.'),(1,0,481,480,1197,'스토리 제목을 입력하세요.'),(2,0,485,484,1621,'말콤의 트라우마'),(1,-220,487,486,1622,'콜의 비밀'),(1,-100,488,487,1623,'말콤에게 마음을 열다'),(1,-220,489,488,1624,'아내의 외도'),(1,-360,490,489,1625,'소녀 유령'),(1,-220,491,490,1626,'말콤과 콜의 친분'),(0,-100,493,492,1621,'별종'),(1,0,497,496,1301,'스토리 제목을 입력하세요.'),(1,-460,500,499,1627,'스토리 제목을 입력하세요.');
/*!40000 ALTER TABLE `story` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:11
