-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team_managers`
--

DROP TABLE IF EXISTS `team_managers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_managers` (
  `managers_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  PRIMARY KEY (`managers_id`,`team_id`),
  KEY `FK368h1mivwun34l5514md068hh` (`team_id`),
  CONSTRAINT `FK368h1mivwun34l5514md068hh` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`),
  CONSTRAINT `FKt0pxomwe0ftv38jn9ryl5qhm2` FOREIGN KEY (`managers_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_managers`
--

LOCK TABLES `team_managers` WRITE;
/*!40000 ALTER TABLE `team_managers` DISABLE KEYS */;
INSERT INTO `team_managers` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,8),(8,14),(9,15),(3,24),(6,26),(7,27),(5,28),(2,48),(6,52),(6,53),(6,54),(6,55),(6,56),(6,59),(10,60),(11,61),(12,62),(13,63),(14,64),(15,65),(16,66),(6,67),(6,68),(7,69),(1,70),(6,71),(6,72),(6,73),(6,74),(6,77),(6,79),(6,81),(6,82),(7,83),(7,84),(1,85),(1,86),(1,87),(1,88),(1,89),(1,90);
/*!40000 ALTER TABLE `team_managers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:10
