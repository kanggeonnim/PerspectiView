-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `story_relation`
--

DROP TABLE IF EXISTS `story_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_relation` (
  `charater_id` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `story_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK97g6unkulh8gvis1hot144n8c` (`charater_id`),
  KEY `FKerbxakv9wk8eijl5cnxu5sv0f` (`story_id`),
  CONSTRAINT `FK97g6unkulh8gvis1hot144n8c` FOREIGN KEY (`charater_id`) REFERENCES `characters` (`id`),
  CONSTRAINT `FKerbxakv9wk8eijl5cnxu5sv0f` FOREIGN KEY (`story_id`) REFERENCES `story` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_relation`
--

LOCK TABLES `story_relation` WRITE;
/*!40000 ALTER TABLE `story_relation` DISABLE KEYS */;
INSERT INTO `story_relation` VALUES (7,3,4),(33,34,87),(29,35,87),(6,39,102),(15,41,102),(6,42,109),(15,43,109),(36,44,110),(36,45,110),(36,46,110),(36,47,110),(36,48,110),(6,49,114),(15,50,114),(33,58,79),(42,59,113),(43,60,113),(43,61,113),(33,62,119),(30,63,80),(33,64,82),(33,65,80),(31,66,83),(33,67,83),(33,68,84),(15,69,117),(33,71,85),(34,72,85),(32,73,85),(60,290,492),(62,291,492),(60,292,484),(61,293,484),(62,294,489),(61,295,488),(60,296,488),(62,297,490),(60,298,490),(63,301,490);
/*!40000 ALTER TABLE `story_relation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:15
