-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_genre`
--

DROP TABLE IF EXISTS `product_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_genre` (
  `genre_id` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnh23rteymy84b58bebbdiw08x` (`genre_id`),
  KEY `FKn0xti883scgkmvh9eo6rpc2ow` (`product_id`),
  CONSTRAINT `FKn0xti883scgkmvh9eo6rpc2ow` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKnh23rteymy84b58bebbdiw08x` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=315 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_genre`
--

LOCK TABLES `product_genre` WRITE;
/*!40000 ALTER TABLE `product_genre` DISABLE KEYS */;
INSERT INTO `product_genre` VALUES (2,7,9),(1,8,10),(1,24,26),(1,25,27),(1,26,28),(1,27,29),(1,67,69),(1,78,80),(1,81,83),(1,82,84),(1,83,85),(1,84,86),(1,86,88),(1,87,89),(1,88,90),(1,89,91),(1,139,122),(1,140,123),(1,141,124),(1,142,125),(1,154,132),(3,167,139),(1,168,140),(1,169,141),(1,228,175),(4,233,178),(1,234,179),(4,235,179),(1,236,180),(1,243,185),(2,244,186),(1,245,187),(2,246,187),(1,247,188),(2,248,188),(3,249,189),(4,250,190),(4,251,191),(3,252,192),(4,253,193),(1,254,194),(1,255,197),(1,256,198),(1,257,199),(2,258,201),(3,259,201),(1,260,202),(1,261,202),(1,262,202),(1,263,202),(1,264,202),(1,270,206),(1,271,206),(1,272,206),(1,273,207),(1,274,207),(1,275,208),(1,285,211),(1,292,161),(3,299,183),(1,300,2),(3,301,2),(1,302,215),(3,303,215),(1,305,216),(1,306,76),(2,307,76),(3,308,76),(4,309,76),(1,310,217),(2,311,218),(2,312,219),(3,313,205),(3,314,220);
/*!40000 ALTER TABLE `product_genre` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:05
