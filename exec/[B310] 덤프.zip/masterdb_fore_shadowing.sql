-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10B310.p.ssafy.io    Database: masterdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fore_shadowing`
--

DROP TABLE IF EXISTS `fore_shadowing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fore_shadowing` (
  `f_shadow_close` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `f_shadow_content` varchar(255) DEFAULT NULL,
  `f_shadow_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1687bncchk94pb64jptn7cpl2` (`product_id`),
  CONSTRAINT `FK1687bncchk94pb64jptn7cpl2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fore_shadowing`
--

LOCK TABLES `fore_shadowing` WRITE;
/*!40000 ALTER TABLE `fore_shadowing` DISABLE KEYS */;
INSERT INTO `fore_shadowing` VALUES (NULL,1,9,'키보드는 먼지가 쌓여있다. 김싸피가 과연 타자를 치고 있었을까?','책상위에 있는 키보드'),(NULL,3,9,'콜록','기침'),(NULL,4,9,'갓 만들어져서 모락모락 연기가 피어나는 커피','방금 만들어진 커피'),(NULL,10,9,'김싸피의 이름이 적혀있는 명찰','싸피 명찰'),(NULL,15,26,'sdfsdf','sdfsdf'),(NULL,17,26,'sdf','dsf'),(NULL,18,26,'sdf','dsf'),(NULL,19,88,'병목에 걸린 종이 표지에는 크고 아름다운 글씨로 “날 마셔요”라고 적혀 있다.','탁자위에 작은 병'),(NULL,20,88,'성격급한 토끼가 계속해서 서두르는듯한 모양새를 보여준다.','토끼가 말하는 공작부인'),(79,21,88,'지루해진 것은 사실 졸고 있었던 것으로 김싸피가 겪은 일은 다 꿈이었다.','언니와 같이 있던 김싸피'),(NULL,22,26,'dfgdfg','dfgdfg'),(117,23,4,'\nclassName에서 문자열 템플릿을 사용하여 동적으로 클래스를 지정하고 있습니다. 그러나 템플릿 문자열을 올바르게 사용하지 않았습니다. 중괄호를 사용하여 변수를 표시해야 합니다.','복선1'),(NULL,24,4,'dsfsdfdsfdsfdsffffffffffffffffffffffffffffff','복선2'),(NULL,25,124,'그냥 하는말인줄 알았는데 나중에 진짜 잡아먹음','상어가 속이 안 좋다고 한다'),(NULL,26,85,'1111','1111'),(NULL,27,88,'항상 12시 정각을 알리며 울고 있는 날개 달린 시계','날개달린 시계'),(NULL,28,2,'test','test'),(NULL,29,4,'\nclassName에서 문자열 템플릿을 사용하여 동적으로 클래스를 지정하고 있습니다. 그러나 템플릿 문자열을 올바르게 사용하지 않았습니다. 중괄호를 사용하여 변수를 표시해야 합니다.\n','복선3'),(NULL,30,4,'','복선 4'),(NULL,31,4,'','5'),(NULL,32,26,'sdfsdfdsf','sdfsf'),(NULL,33,179,'복선 1ㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇ','복선1_수정 테스트'),(NULL,34,179,'복선 2','복선 2 '),(NULL,35,179,'복선 3','복선 3'),(NULL,37,179,'복선 생성 생성','복선 생성 생성'),(NULL,38,132,'부하 테스트용 복선','부하테스트복선'),(NULL,39,193,'죽음과 공포와 연관된 것. 죽음과 관련된 것에 나타난다.','빨간색'),(NULL,41,193,'귀신을 볼 수 없는 사람들은 말콤을 인식할 수도 말을 걸 수 도 없다.','말콤에게 말을 하지 않는 아내'),(NULL,42,4,'','dddddddddd'),(NULL,43,4,'sdfsdf','sddd'),(NULL,44,4,'','sdfsdf'),(NULL,45,193,'죽은 사람들은 자신이 보고 싶은 것만 보고 자신이 죽은지도 모른다','콜 시어의 유령에 대한 말'),(NULL,47,83,'123','123'),(NULL,48,83,'123','123'),(NULL,49,83,'222','222'),(359,50,183,'231','gads'),(NULL,51,183,'521353','123');
/*!40000 ALTER TABLE `fore_shadowing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:00:09
